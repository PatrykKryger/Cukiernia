import {Outlet} from "react-router-dom";
import img from './logo.png';
import "./pasek.css";

export const RootLayout = () => (
    <>
    <div className="pasek">
        <a href={"/wypozyczalnia"}>
            <img src={img} className="logo"/>
        </a>
        <a href={"/wypozyczalnia/logowanie"} className="logowanie">
            <button>Logowanie</button>
        </a>

    </div>
        <Outlet/>
    </>

);
