import "./chron.css";
import {useEffect} from "react";
export const Chron = () => {

    useEffect(() => {

        if (localStorage.getItem('email')===null) {
            window.location.href = '/wypozyczalnia/logowanie';
        }
    }, []);
    const imie = JSON.parse(window.localStorage.getItem("imie"));
    const nazwisko = JSON.parse(window.localStorage.getItem("nazwisko"));
    const handleLogout = () => {
        localStorage.removeItem('email');
        localStorage.removeItem('imie');
        localStorage.removeItem('nazwisko');
        window.location.href = '/wypozyczalnia';
    };
    console.log(localStorage.getItem('email'));


    return (
        <div className="koniec">
            <h2>Witaj {imie} {nazwisko}</h2>
            <button onClick={handleLogout}>Wyloguj</button>
        </div>
    );

} 