import React from 'react';

const OcenaGwiazdkowa = ({ ocena }) => (
    <div>
        {[...Array(5)].map((_, index) => (
            <span key={index} style={{ color: index < ocena ? '#ffc107' : '#ccc' }}>
        &#9733;
      </span>
        ))}
    </div>
);

export default OcenaGwiazdkowa;