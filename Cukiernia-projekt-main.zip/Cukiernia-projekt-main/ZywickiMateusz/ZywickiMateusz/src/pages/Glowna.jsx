import "./glowna.css";

import { Link } from "react-router-dom";
import jan from './jan.jpg';
import victor from './victor.jpg';
import mikolaj from './mikolaj.jpg';
import insta from './insta.png';
import face from './face.webp';
import ciasto from './ciasto3.png';
import OcenaGwiazdkowa from "./OcenaGwiazdkowa.jsx";
/*
function Przeniesienie(){
    browserHistory.push("/path-to-link");
}*/
export const Glowna = () => {
    return (
        <body>

        <div className="hero">

            <img src={ciasto} className="kamper"/>
            <Link to={{pathname: '/wypozyczalnia/rejestracja'}}>
                <button className="cat">Załóz konto</button>
            </Link>


        </div>
        <div className="wyr">
            <div className="op">
                <h3>Niepowtarzalne wypieki na każdą okazję</h3>
                <span>Nasza cukiernia oferuje niepowtarzalne torty i ciasta, które idealnie wpisują się w indywidualne potrzeby naszych klientów. Niezależnie od tego, czy świętujesz urodziny, wesele, czy inną ważną chwilę, nasze wypieki zachwycają nie tylko smakiem, ale i wyglądem, czyniąc każdą okazję wyjątkową.</span>
            </div>
            <div className="op">
                <h3>Bliska więź z klientami i lokalną społecznością</h3>
                <span>Nasza cukiernia buduje relacje oparte na zaufaniu i przyjaznej atmosferze. Organizujemy degustacje, doceniamy stałych klientów i z dumą angażujemy się w lokalne inicjatywy. Dzięki temu jesteśmy czymś więcej niż miejscem sprzedaży – jesteśmy częścią Twojej codzienności.</span>
            </div>
            <div className="op">
                <h3>Trendy i sezonowość w naszych wypiekach</h3>
                <span>Nasza cukiernia stale podąża za kulinarnymi trendami, wprowadzając sezonowe smaki i wyjątkowe produkty. Od popularnych składników, takich jak pistacje czy czekolada ruby, po nowoczesne metody dekoracji – nasze wypieki zawsze zachwycają świeżością i oryginalnością.</span>
            </div>
        </div>
        <div className="opis">

            <div className="bord">
                <div className="tlo">
                    <span>Witaj w <span className="idk">RanpnerRental</span> – Twoim partnerze w podróżach kamperem! Oferujemy różnorodne, bezpieczne kampery do wynajęcia, dostosowane do Twoich potrzeb. Rezerwacja online, obsługa 24/7, i pasja do podróży. Rozpocznij niezapomnianą przygodę z nami już dziś!
                </span></div>
            </div>
        </div>
        <div className="opinie">

            <div className="opinia">
                <img src={jan}/>
                <h2>Jan</h2><br/>  <OcenaGwiazdkowa ocena={5} />
                Cudowne miejsce! Tort zamówiony na urodziny przerósł moje oczekiwania – pięknie wykonany i przepyszny. Goście byli zachwyceni, a ja na pewno wrócę przy następnej okazji. Polecam z całego serca!

            </div>
            <div className="opinia">
                <img src={victor}/>
                <h2>Wiktor</h2>  <OcenaGwiazdkowa ocena={5} />
                Najlepsze ciasta, jakie jadłam! Wszystko świeże, pachnące i idealnie doprawione. Obsługa bardzo miła i pomocna, zawsze doradzą w wyborze. Polecam zwłaszcza sernik – to prawdziwa poezja smaku!
            </div>
            <div className="opinia">
                <img src={mikolaj}/>
                <h2>Mikołaj</h2> <OcenaGwiazdkowa ocena={4} />
                Wypieki są naprawdę smaczne, a tort, który zamówiłam, wyglądał obłędnie. Jedyny drobny minus to czas oczekiwania – warto zamawiać z wyprzedzeniem. Poza tym – super jakość i profesjonalna obsługa!
            </div>
        </div>

            <div className="stopa">
                <div className="info">
                <ul>
                    <li>
                        Numer: 555 555 555
                    </li>
                    <li>
                        Adres: Suchy Las
                    </li>
                    <li>
                        Ulica: Stara Droga
                    </li>
                    <li>
                        Kod pocztowy: 06335
                    </li>
                </ul></div>
                <div className="social">
                    <img src={face}/>
                    <img src={insta}/>
                </div>
            </div>

        </body>
    )
};


