import {useForm} from "react-hook-form";
import "./rejestracja.css";
export const Test = () => {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({
        mode: 'onSubmit',
        reValidateMode: 'onChange',
    })



    return (
        <div className="form">
        <form onSubmit={handleSubmit((data) => console.log(data))}>
            <label>Imię:</label>
            <input {...register('imie', {
                required: true, minLength: {value: 3, message: 'Imie musi miec co najmniej 3 znaki'}
            })} />
            {errors.imie && <p>{errors.imie.message}</p>}
            <br/>
            <label>Nazwisko:</label>
            <input {...register('nazwisko', {
                required: true, minLength: {value: 3, message: 'Nazwisko musi miec co najmniej 3 znaki'}
            })} />
            {errors.nazwisko && <p>{errors.nazwisko.message}</p>}
            <br/>
            <label>Email:</label>
            <input {...register('email', {
                required: true, pattern: {value: /^\S+@\S+\.\S{2,}$/, message: 'Nieprawidłowy adres e-mail'}
            })} />
            {errors.email && <p>{errors.email.message}</p>}
            <br/>
            <label>Numer telefonu:</label>
            <input type={"tel"} {...register('numer', {
                required: true, message: 'Wprowadź numer telefonu.'
            })} />
            {errors.numer && <p>{errors.numer.message}</p>}
            <br/>
            <label>Miasto:</label>
            <select {...register('miasto', {required: true})}>
                <option value="Gdansk">Gdansk</option>
                <option value="Gdynia">Gdynia</option>
                <option value="Kościerzyna">Koscierzyna</option>
                <option value="Borkowo">Borkowo</option>
            </select>
            {errors.miasto && <p>{errors.miasto.message}</p>}
            <br/>
            <label>Haslo:</label>
            <input type={"password"} {...register('haslo', {
                required: true, minLength: { value: 8, message: 'Hasło musi mieć co najmniej 8 znaków' }, maxLength: { value: 30, message: 'Hasło nie może przekraczać 30 znaków' },
                pattern: {
                    value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/,
                    message: 'Hasło musi zawierać przynajmniej jedną dużą literę, jedną małą literę i cyfrę'}
            })} />
            {errors.haslo && <p>{errors.haslo.message}</p>}
            <br/>
            <button type="submit">Wyślij</button>
        </form></div>
    );
}