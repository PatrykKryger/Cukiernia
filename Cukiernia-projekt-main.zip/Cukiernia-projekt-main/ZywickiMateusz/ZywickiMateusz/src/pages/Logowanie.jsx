import {useForm} from "react-hook-form";
import { useNavigate} from "react-router-dom";
import "./logowanie.css";

export const Log = () => {
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({
        mode: 'onSubmit',
        reValidateMode: 'onChange',
    })
    const navigate = useNavigate();
    const onSubmit = async data => {
        if(data.email === "test@gmail.com" && data.haslo === "zaq1@WSXcde3" || data.email === "test2@gmail.com" && data.haslo === "ZAQ!2wsxCDE#"){
            localStorage.setItem("email", JSON.stringify(data.email));
            localStorage.setItem("imie", JSON.stringify('Jan'));
            localStorage.setItem("nazwisko", JSON.stringify('Nowak'));
            navigate('/wypozyczalnia/Chron');
        }else{
            alert("Podaj poprawne hasło lub email.");
        }
    };

    return(
        <div className="for">
        <form className="formu" onSubmit={handleSubmit(onSubmit)
        }>
            <label>Email:</label>
            <input {...register('email', {
                required: true,
                pattern: {value: /^\S+@\S+\.\S{2,}$/, message: 'Nieprawidłowy adres e-mail.'}
            })} />
            {errors.email && <p>{errors.email.message}</p>}
            <br/>
            <label>Haslo:</label>
            <input type={"password"} {...register('haslo', {
                required: true,
                minLength: {value: 8, message: 'Hasło musi mieć co najmniej 8 znaków.'},
                maxLength: {value: 30, message: 'Hasło nie może przekraczać 30 znaków.'},
                pattern: {
                    value: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/,
                    message: 'Hasło musi zawierać przynajmniej jedną dużą literę, jedną małą literę i cyfrę.'
                }
            })} />
            {errors.haslo && <p>{errors.haslo.message}</p>}
            <br/><br/>
            <button type="submit" className="zalogb">Zaloguj</button>

        </form></div>


    )
};