import React from 'react'
import ReactDOM from 'react-dom/client'
import './index.css'
import {createBrowserRouter, Navigate, RouterProvider} from "react-router-dom";
import {RootLayout} from "./layouts/RootLayout.jsx";
import {Glowna} from "./pages/Glowna.jsx";
import {Log} from "./pages/Logowanie.jsx";
import {Test} from "./pages/Test.jsx";
import {Chron} from "./pages/Chron.jsx";

const router = createBrowserRouter([
  { path: '/', element: <RootLayout />, children: [
      { path: '/', element: <Navigate to={'/wypozyczalnia'} /> },
      { path: '/wypozyczalnia', element: <Glowna/> },
          {path: '/wypozyczalnia/logowanie', element: <Log />},
          {path: '/wypozyczalnia/rejestracja', element: <Test />},
          {path: '/wypozyczalnia/chron', element: <Chron />},
    ], },
])

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
)
