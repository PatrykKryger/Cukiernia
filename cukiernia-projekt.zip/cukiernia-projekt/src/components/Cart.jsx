import { Link } from "react-router-dom";
import './styles/global.css';

const Cart = () => (
    <div className="container">
            <div className="card">
                    <h2>Your Cart</h2>
                    <ul>
                            {["Chocolate Cake", "Vanilla Cake"].map((cake, index) => (
                                <li key={index}>
                                        <span>{cake}</span>
                                        <button className="bg-red-500 text-white rounded">Remove</button>
                                </li>
                            ))}
                    </ul>
                    <Link to="/payment" className="link mt-3 text-center block"><button className="bg-blue-500 text-white rounded mt-5">Checkout</button></Link>
                    <Link to="/cakes" className="link mt-3 text-center block">Back to Cakes</Link>
            </div>
    </div>
);

export default Cart;
