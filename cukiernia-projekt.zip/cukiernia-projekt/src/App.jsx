import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Login from "./components/Login";
import Register from "./components/Register";
import CreateCake from "./components/CreateCake";
import Cakes from "./components/Cakes";
import Cart from "./components/Cart";
import Payment from "./components/Payment";
import Settings from "./components/Settings";
import Main from "./components/Main";
import Logo from "./components/images/logocukiernia.png";
import './App.css';

const App = () => {
    return (
        <Router>
            <div className="container">
                <nav className="navbar">
                    <Link to="/" className="nav-link"><img src={Logo} alt="logo" className="logo" /></Link>
                    <Link to="/login" className="nav-link">Login</Link>
                    <Link to="/create-cake" className="nav-link">Create Cake</Link>
                    <Link to="/cakes" className="nav-link">Cakes</Link>
                    <Link to="/cart" className="nav-link">Cart</Link>
                    <Link to="/settings" className="nav-link">Settings</Link>
                </nav>
                <Routes>
                    <Route path="/" element={<Main />} />
                    <Route path="/login" element={<Login />} />
                    <Route path="/register" element={<Register />} />
                    <Route path="/create-cake" element={<CreateCake />} />
                    <Route path="/cakes" element={<Cakes />} />
                    <Route path="/cart" element={<Cart />} />
                    <Route path="/payment" element={<Payment />} />
                    <Route path="/settings" element={<Settings />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
